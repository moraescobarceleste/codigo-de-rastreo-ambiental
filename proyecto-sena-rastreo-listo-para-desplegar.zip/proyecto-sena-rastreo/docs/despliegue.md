# Despliegue del backend en Railway

Railway permite alojar la API y la base MySQL en el mismo proyecto. Render **no** ofrece MySQL
administrado (solo PostgreSQL), por eso se recomienda Railway para este proyecto. Revisa en
railway.com los planes y el crédito de prueba vigentes antes de crear el proyecto.

## Antes de empezar

- El código debe estar en un repositorio de GitHub (el `.gitignore` ya evita subir `.env` y `node_modules`).
- La API queda lista para producción: sesión guardada en MySQL, cookie `Secure` + `SameSite=None`,
  CORS por lista de orígenes y `SESSION_SECRET` obligatorio.

## Pasos

1. **Crear el proyecto.** En Railway: *New Project → Deploy from GitHub repo* y elige este repositorio.
2. **Apuntar al backend.** En el servicio creado: *Settings → Root Directory* = `backend`.
   Railway leerá `backend/railway.json` (comando `npm run start:prod` y healthcheck `/api/health`).
3. **Agregar MySQL.** En el lienzo del proyecto: *+ New → Database → MySQL*.
4. **Variables del servicio de la API** (*Variables* del servicio backend, no del de MySQL):

   | Variable | Valor |
   |----------|-------|
   | `NODE_ENV` | `production` |
   | `MYSQL_URL` | `${{MySQL.MYSQL_URL}}` (referencia al servicio de MySQL; ajusta el nombre si lo cambiaste) |
   | `SESSION_SECRET` | una cadena larga y aleatoria (`openssl rand -hex 32`) |
   | `CLIENT_URL` | URL del frontend, sin `/` al final (se completa en el paso 7) |
   | `ALLOW_PRIVILEGED_SIGNUP` | `false` |

   `PORT` lo define Railway; no lo agregues.
5. **Desplegar.** Al arrancar, `start:prod` ejecuta `scripts/init-db.js`, que crea las tablas si no
   existen, y luego inicia la API. Revisa *Deployments → Logs*: debe aparecer
   `Base de datos lista` y `API Rastreo Ambiental ejecutándose`.
6. **Obtener la URL pública.** *Settings → Networking → Generate Domain*. Prueba:
   `https://TU-API.up.railway.app/api/health` → `{"ok":true,...}`.
7. **Conectar el frontend.** Al publicar el frontend (Vercel, Netlify, etc.) define
   `VITE_API_URL=https://TU-API.up.railway.app/api`. Luego vuelve a la API y pon en
   `CLIENT_URL` la URL final del frontend. Guarda para que se redespliegue.

## Crear el primer administrador

El registro público solo crea ciudadanos. Para crear un administrador:

1. Pon `ALLOW_PRIVILEGED_SIGNUP=true` en Railway y espera el redespliegue.
2. Regístralo desde el formulario del frontend.
3. Vuelve a poner `ALLOW_PRIVILEGED_SIGNUP=false` **de inmediato**.

## Problemas frecuentes

| Síntoma | Causa probable |
|---------|----------------|
| `Define SESSION_SECRET...` en los logs | Falta `SESSION_SECRET` en el servicio de la API |
| `ECONNREFUSED` / `ENOTFOUND` a MySQL | `MYSQL_URL` no está en las variables del servicio de la API |
| Error de CORS en el navegador | `CLIENT_URL` no coincide exactamente con el origen del frontend |
| El login responde bien pero no se mantiene la sesión | El frontend debe usar HTTPS y `credentials: "include"` (ya está en `api.ts`) |
| Healthcheck falla | El *Root Directory* no es `backend` |

## Si prefieres Render

Render solo ofrece PostgreSQL administrado. Para MySQL tendrías que crear un *Private Service* con
Docker y disco, o usar un MySQL externo. La API funciona igual con cualquiera: define `MYSQL_URL`
(o `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`) y `DB_SSL=true` si el proveedor lo exige.
